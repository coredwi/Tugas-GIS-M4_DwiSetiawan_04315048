package com.example.windows10.templemaps

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity4 : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap1: GoogleMap
    private lateinit var mMap2: GoogleMap
    private lateinit var mMap3: GoogleMap
    private lateinit var mMap4: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap1 = googleMap
        mMap2 = googleMap
        mMap3 = googleMap
        mMap4 = googleMap

        // Mojokerto
        val CandiSumberawan = LatLng(-7.855185, 112.644801)
        mMap1.addMarker(MarkerOptions().position(CandiSumberawan).title("CANDI SUMBERAWAN"))
        mMap1.moveCamera(CameraUpdateFactory.newLatLng(CandiSumberawan))

       val CandiSonggoriti = LatLng(-7.867060, 112.492701)
       mMap2.addMarker(MarkerOptions().position(CandiSonggoriti).title("CANDI SONGGORITI"))
       mMap2.moveCamera(CameraUpdateFactory.newLatLng(CandiSonggoriti))

        val CandiSingosari = LatLng(-7.887578, 112.663892)
       mMap3.addMarker(MarkerOptions().position(CandiSingosari).title("CANDI SINGOSARI"))
       mMap3.moveCamera(CameraUpdateFactory.newLatLng(CandiSingosari))

       val CandiJago = LatLng(-8.005801, 112.764108)
       mMap4.addMarker(MarkerOptions().position(CandiJago).title("CANDI JAGO"))
       mMap4.moveCamera(CameraUpdateFactory.newLatLng(CandiJago))

        mMap1.setMyLocationEnabled(true);
        mMap1.animateCamera(CameraUpdateFactory.zoomTo(10.0f));
        mMap1.getUiSettings().setZoomControlsEnabled(true);

        mMap2.setMyLocationEnabled(true);
        mMap2.animateCamera(CameraUpdateFactory.zoomTo(10.0f));
        mMap2.getUiSettings().setZoomControlsEnabled(true);

        mMap3.setMyLocationEnabled(true);
        mMap3.animateCamera(CameraUpdateFactory.zoomTo(10.0f));
        mMap3.getUiSettings().setZoomControlsEnabled(true);

        mMap4.setMyLocationEnabled(true);
        mMap4.animateCamera(CameraUpdateFactory.zoomTo(10.0f));
        mMap4.getUiSettings().setZoomControlsEnabled(true);
    }
}