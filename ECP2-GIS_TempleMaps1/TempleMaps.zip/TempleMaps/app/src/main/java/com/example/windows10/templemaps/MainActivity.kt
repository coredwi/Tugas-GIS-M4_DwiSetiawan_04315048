//maps candi di blitar
package com.example.windows10.templemaps

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fun readData(): MutableList<Array> {
            val list = ArrayList<Array>()
            list.add(Array(1, "SURABAYA", "asd", "asd"))
            list.add(Array(2, "MOJOKERTO", "asd", "asd"))
            list.add(Array(3, "BLITAR", "asd", "asd"))
            list.add(Array(4, "MALANG", "asd", "asd"))
            list.add(Array(5, "PASURUAN", "asd", "asd"))

            list.add(Array("abc", "asd", "asd"))
            return list
        }

        //**Button Click SURABAYA**//
        btnSurabaya.setOnClickListener {
            val maintomap = Intent(this, MapsActivity::class.java)
            startActivity(maintomap)
        }
        //**Button Click MOJOKERTO**//
        btnMojokerto.setOnClickListener {
            val maintomap = Intent(this, MapsActivity2::class.java)
            startActivity(maintomap)
        }
        //**Button Click BLITAR**//
        btnBlitar.setOnClickListener {
            val maintomap = Intent(this, MapsActivity3::class.java)
            startActivity(maintomap)
        }
        //**Button Click MALANG**//
        btnMalang.setOnClickListener {
            val maintomap = Intent(this, MapsActivity4::class.java)
            startActivity(maintomap)
        }
        //**Button Click PASURUAN**//
        btnPasuruan.setOnClickListener {
            val maintomap = Intent(this, MapsActivity5::class.java)
            startActivity(maintomap)
        }

        //**Button Click VIEW ALL**//
        btnViewAll.setOnClickListener {
            val maintomap = Intent(this, MapsActivity6::class.java)
            startActivity(maintomap)
        }

        //**Button Click ABOUT**//
        btnAbout.setOnClickListener {
            val maintomap = Intent(this, Main2Activity::class.java)
            startActivity(maintomap)
        }
    }
}
