package com.example.windows10.templemaps

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity6 : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // arca joko dolog
        val ArcaJokoDolog = LatLng(-7.264884, 112.742770)
        mMap.addMarker(MarkerOptions().position(ArcaJokoDolog).title("Arca Joko Dolog"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ArcaJokoDolog))

        // Mojokerto
        val CandiBrahu = LatLng(-7.542904, 112.374399)
        mMap.addMarker(MarkerOptions().position(CandiBrahu).title("CANDI BRAHU"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiBrahu))

        val CandiTikus = LatLng(-7.571725, 112.403529)
        mMap.addMarker(MarkerOptions().position(CandiTikus).title("CANDI TIKUS"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiTikus))

        val CandiBajangratu = LatLng(-7.567689, 112.398785)
        mMap.addMarker(MarkerOptions().position(CandiBajangratu).title("CANDI BAJANG RATU"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiBajangratu))

        // BLITAR
        val CandiPenataran = LatLng(-8.016423, 112.209739)
        mMap.addMarker(MarkerOptions().position(CandiPenataran).title("CANDI PENATARAN"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiPenataran))

        val CandiKlicilik  = LatLng(-7.997948, 112.140286)
        mMap.addMarker(MarkerOptions().position(CandiKlicilik).title("CANDI KLICILIK"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiKlicilik))

        val CandiPlumbangan = LatLng(-8.074445, 112.339655)
        mMap.addMarker(MarkerOptions().position(CandiPlumbangan).title("CANDI PLUMBANGAN"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiPlumbangan))

        // Mojokerto
        val CandiSumberawan = LatLng(-7.855185, 112.644801)
        mMap.addMarker(MarkerOptions().position(CandiSumberawan).title("CANDI SUMBERAWAN"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiSumberawan))

        val CandiSonggoriti = LatLng(-7.867060, 112.492701)
        mMap.addMarker(MarkerOptions().position(CandiSonggoriti).title("CANDI SONGGORITI"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiSonggoriti))

        val CandiSingosari = LatLng(-7.887578, 112.663892)
        mMap.addMarker(MarkerOptions().position(CandiSingosari).title("CANDI SINGOSARI"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiSingosari))

        val CandiJago = LatLng(-8.005801, 112.764108)
        mMap.addMarker(MarkerOptions().position(CandiJago).title("CANDI JAGO"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiJago))

        // Pasuruan
        val CandiGunungGangsir = LatLng(-7.586787, 112.733438)
        mMap.addMarker(MarkerOptions().position(CandiGunungGangsir).title("CANDI GUNUNG GANGSIR"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiGunungGangsir))

        val CandiJawi = LatLng(-7.662510, 112.669934)
        mMap.addMarker(MarkerOptions().position(CandiJawi).title("CANDI JAWI"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiJawi))

        val CandiBelahan = LatLng(-7.607429, 112.651590)
        mMap.addMarker(MarkerOptions().position(CandiBelahan).title("CANDI BELAHAN"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiBelahan))

        mMap.setMyLocationEnabled(true);
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 8.0f ) );
        mMap.getUiSettings().setZoomControlsEnabled(true);
    }
}