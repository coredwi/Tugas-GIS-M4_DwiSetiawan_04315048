package com.example.windows10.templemaps

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity2 : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Mojokerto
        val CandiBrahu = LatLng(-7.542904, 112.374399)
        mMap.addMarker(MarkerOptions().position(CandiBrahu).title("CANDI BRAHU"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiBrahu))

        val CandiTikus = LatLng(-7.571725, 112.403529)
        mMap.addMarker(MarkerOptions().position(CandiTikus).title("CANDI TIKUS"))
        mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiTikus))

       val CandiBajangratu = LatLng(-7.567689, 112.398785)
       mMap.addMarker(MarkerOptions().position(CandiBajangratu).title("CANDI BAJANG RATU"))
       mMap.moveCamera(CameraUpdateFactory.newLatLng(CandiBajangratu))

       mMap.setMyLocationEnabled(true);
       mMap.animateCamera( CameraUpdateFactory.zoomTo( 10.0f ) );
       mMap.getUiSettings().setZoomControlsEnabled(true);
    }
}