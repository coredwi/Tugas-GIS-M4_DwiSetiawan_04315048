package com.example.windows10.templemaps

class Array {
    var rowid: Int = 0
    var loc: String = ""
    var long: String = ""
    var lat: String = ""

    constructor(rowid: Int, loc: String, long: String, lat: String){
        this.rowid  = rowid
        this.loc = loc
        this.long   = long
        this.lat    = lat
    }
    constructor(loc: String, long: String, lat: String){
        this.loc = loc
        this.long   = long
        this.lat    = lat
    }
}

